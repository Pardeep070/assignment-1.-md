package com.example.usercomputerdice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView leftDieImg, rightDieImg;
    Button leftHigherBtn, rightLowerBtn;

    TextView resultView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        leftDieImg = findViewById(R.id.left_die);
        rightDieImg = findViewById(R.id.right_die);

        leftHigherBtn = findViewById(R.id.btnHigherLeft);
        rightLowerBtn = findViewById(R.id.btnLowerRight);

        resultView = findViewById(R.id.txtVOutput);

        int[] array_die = {R.drawable.dice1,
                R.drawable.dice2,
                R.drawable.dice3,
                R.drawable.dice4,
                R.drawable.dice5,
                R.drawable.dice6};

        leftHigherBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commonFunc(array_die, "leftHigherBtn");
            }
        });

        rightLowerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commonFunc(array_die, "");
            }
        });
    }

    public void commonFunc (int[] array_die, String inputString) {
        int leftRandomRoll = RandomRollGenerate();
        int rightRandomRoll = RandomRollGenerate();

        leftDieImg.setImageResource(array_die[leftRandomRoll]);
        rightDieImg.setImageResource(array_die[rightRandomRoll]);

        if (inputString.equals("leftHigherBtn")) {
            resultView.setText(winningText(leftRandomRoll, rightRandomRoll, "leftHigherBtn"));
        } else {
            resultView.setText(winningText(leftRandomRoll, rightRandomRoll, ""));
        }
    }

    public int RandomRollGenerate() {
        Random random_roll = new Random();
        return random_roll.nextInt(6);
    }

    public String winningText ( int user , int computer, String inputText) {
        String resultText = "";
        if ( inputText.equals("leftHigherBtn")) { // Higher button is clicked
            if (user > computer) {
                resultText = "User wins!".toUpperCase();
            } else if (user < computer) {
                resultText =  "Computer wins!".toUpperCase();
            } else {
                resultText = "It’s a tie!".toUpperCase();
            }
        } else { // Lower button  is clicked
            if (user < computer) {
                resultText = "User wins!".toUpperCase();
            } else if (user > computer) {
                resultText =  "Computer wins!".toUpperCase();
            } else {
                resultText = "It’s a tie!".toUpperCase();
            }
        }
        return resultText;
    }
}